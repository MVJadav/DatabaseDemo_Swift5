//
//  AppUtility.swift
//  DatabaseDemo
//
//  Created by Mehul Jadav.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation
import UIKit


class AppUtility: NSObject {

    
    public static let `default` = AppUtility()
    @objc var navigationController: UINavigationController?
    
}
