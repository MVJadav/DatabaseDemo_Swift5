//
//  Constant.swift
//  DatabaseDemo
//
//  Created by Mehul Jadav.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation
import UIKit


struct App {

    struct Storyboard {
        static let main = UIStoryboard(name: "Main", bundle: nil)
        
    }
    
}

struct AppColor {

    static let AppTheme_Primary         = UIColor(red: 105/255, green: 198/255, blue: 192/255, alpha: 1.0)
    static let Dark_Black       = UIColor(red: 24/255, green: 25/255, blue: 27/255 , alpha :1.0)
}

//Model Name
struct CustomModelName {
    
    //Contact Screen
    static let Data = "Data"
}
