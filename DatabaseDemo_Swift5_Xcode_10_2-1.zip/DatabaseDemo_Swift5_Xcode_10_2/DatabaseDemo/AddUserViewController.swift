//
//  AddUserViewController.swift
//  DatabaseDemo
//
//  Created by Mehul Jadav.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

@objc protocol AddUserDelegate:class {
    @objc optional func didFinishAddUser()
}

class AddUserViewController: UIViewController {

    var delegate:AddUserDelegate?
    
    @IBOutlet weak var IBtxtName                : UITextField!
    @IBOutlet weak var IBtxtNumber              : UITextField!
    @IBOutlet weak var IBtxtAddress             : UITextField!
    @IBOutlet weak var IBbtnMale                : UIButton!
    @IBOutlet weak var IBbtnFemale              : UIButton!

    @IBOutlet weak var IBSubviewNameError       : UIView!
    @IBOutlet weak var IBSubviewNumberError     : UIView!
    @IBOutlet weak var IBSubviewAddressError    : UIView!
    
    var userId : CLong = 0
    var objUserModel:UserModel = UserModel()
    var gender = "Male"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated:true);
        self.setView()
        if self.userId > 0 {
            self.setData()
        }
    }
}

//MARK:- IBAction Methods.
extension AddUserViewController {
    
    @IBAction func barbtnBackClick(sender: AnyObject) {
        AppUtility.default.navigationController!.popViewController(animated: true)
    }
    
    @IBAction func barbtnDoneClick(sender: AnyObject) {
        
        if ValidationAll() {
            self.addUser()
        }
        
    }
    
    @IBAction func clickOnGender(_ sender: UIButton) {
        
        if sender.tag == 101 {
            self.IBbtnMale.backgroundColor        = AppColor.AppTheme_Primary
            self.IBbtnMale.setTitleColor(UIColor.white, for: .normal)
            
            self.IBbtnFemale.backgroundColor        = UIColor.lightGray
            self.IBbtnFemale.setTitleColor(AppColor.Dark_Black, for: .normal)
            self.gender = "Male"
        }else {
            self.IBbtnFemale.backgroundColor        = AppColor.AppTheme_Primary
            self.IBbtnFemale.setTitleColor(UIColor.white, for: .normal)
            
            self.IBbtnMale.backgroundColor        = UIColor.lightGray
            self.IBbtnMale.setTitleColor(AppColor.Dark_Black, for: .normal)
            self.gender = "Female"
        }
    }
}

//MARK:- Other Methods
extension AddUserViewController {
    
    func setView() {
        self.IBbtnMale.backgroundColor = AppColor.AppTheme_Primary
        self.IBbtnMale.setTitleColor(UIColor.white, for: .normal)
        self.IBbtnFemale.backgroundColor = UIColor.lightGray
        self.IBbtnFemale.setTitleColor(AppColor.Dark_Black, for: .normal)
    }
    
    func setData() {
        
        if let name = self.objUserModel.user_name {
            self.IBtxtName.text = name
        }
        if let number = self.objUserModel.number {
            self.IBtxtNumber.text = number
        }
        if let address = self.objUserModel.address {
            self.IBtxtAddress.text = address
        }
        if let gender = self.objUserModel.gender {
            self.gender = gender
            if self.gender == "Male" {
                self.IBbtnMale.backgroundColor        = AppColor.AppTheme_Primary
                self.IBbtnMale.setTitleColor(UIColor.white, for: .normal)
                
                self.IBbtnFemale.backgroundColor        = UIColor.lightGray
                self.IBbtnFemale.setTitleColor(AppColor.Dark_Black, for: .normal)
            }else {
                self.IBbtnFemale.backgroundColor        = AppColor.AppTheme_Primary
                self.IBbtnFemale.setTitleColor(UIColor.white, for: .normal)
                
                self.IBbtnMale.backgroundColor        = UIColor.lightGray
                self.IBbtnMale.setTitleColor(AppColor.Dark_Black, for: .normal)
            }
        }
    }
    
}

//MARK:- Validation Methods
extension AddUserViewController {
    
    func ValidationAll() -> Bool{
        
        var falg:Bool = true
        if(self.Validation(textField: self.IBtxtName) == false){
            falg = false
        }else if(self.Validation(textField: self.IBtxtNumber) == false){
            falg = false
        }else if(self.Validation(textField: self.IBtxtAddress) == false){
            falg = false
        }
        return falg
    }
    
    func Validation(textField: UITextField) -> Bool {
        var flag:Bool = true
        
        if textField == IBtxtName {
            if IBtxtName.text?.isEmpty == true {
                //self.AlertMessage(msg: "Insert Name")
                self.IBSubviewNameError.backgroundColor = UIColor.red
                flag = false;
            }else {
                self.IBSubviewNameError.backgroundColor = UIColor.lightGray
            }
        }
        if textField == IBtxtNumber {
            if IBtxtNumber.text?.isEmpty == true {
                //self.AlertMessage(msg: "Insert Number")
                self.IBSubviewNumberError.backgroundColor = UIColor.red
                flag = false;
            }else {
                self.IBSubviewNumberError.backgroundColor = UIColor.lightGray
            }
        }
        if textField == IBtxtAddress {
            if IBtxtAddress.text?.isEmpty == true {
                //self.AlertMessage(msg: "Insert Address")
                self.IBSubviewAddressError.backgroundColor = UIColor.red
                flag = false;
            }else {
                self.IBSubviewAddressError.backgroundColor = UIColor.lightGray
            }
        }
        return flag
    }
}

//MARK:- Service Call
extension AddUserViewController {
    
    func addUser() {
        
        if (self.IBtxtName.text?.isEmpty)! {}else{
            objUserModel.user_name = self.IBtxtName.text
        }
        if (self.IBtxtNumber.text?.isEmpty)! {}else{
            objUserModel.number = self.IBtxtNumber.text
        }
        if (self.IBtxtAddress.text?.isEmpty)! {}else{
            objUserModel.address = self.IBtxtAddress.text
        }
        objUserModel.gender = self.gender
        
        var query = ""
        if self.userId > 0 {
            query = DBQuery().update(Obj: objUserModel)
        }else {
            query = DBQuery().insert(Obj: objUserModel)
        }
        if DBHelper.GeneralQuery(queryString: query) {
            self.delegate?.didFinishAddUser!()
            _ =  self.navigationController?.popViewController(animated: true)
        }else {}
        
    }
    
}
