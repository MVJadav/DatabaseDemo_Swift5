//
//  ViewController.swift
//  DatabaseDemo
//
//  Created by Mehul Jadav.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import ObjectMapper

class ViewController: UIViewController {

    @IBOutlet weak var IBuserTbl            : UITableView!
    
    var objUser                                 : [UserModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "User List"
        self.setView()
        self.getUserList()
    }
}

//MARK:- IBAction Methods.
extension ViewController {
    
    @IBAction func barbtnAddClick(sender: AnyObject) {
        let addUser = App.Storyboard.main.instantiateVC(AddUserViewController.self)!
        addUser.delegate = self
        AppUtility.default.navigationController!.pushViewController(addUser, animated: true)
    }
}

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if( self.objUser.count > 0 ){
            return self.objUser.count
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        var cell:StudentCell? = tableView.dequeueReusableCell(withIdentifier: "StudentCell") as? StudentCell
        if (cell == nil) {
            let nib: NSArray = Bundle.main.loadNibNamed("StudentCell", owner: self, options: nil)! as NSArray
            cell = nib.object(at: 0) as? StudentCell
        }
        cell?.selectionStyle = .none
        cell?.user = self.objUser[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let addUser = App.Storyboard.main.instantiateVC(AddUserViewController.self)!
        addUser.userId = self.objUser[indexPath.row].userId!
        addUser.objUserModel = self.objUser[indexPath.row]
        addUser.delegate = self
        AppUtility.default.navigationController!.pushViewController(addUser, animated: true)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    internal func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCell.EditingStyle.delete) {
            
            if let userId = self.objUser[indexPath.row].userId {
                
                let alertController = UIAlertController(title: "Delete", message: "Are you sure you want to delete this user", preferredStyle: UIAlertController.Style.alert) //Replace UIAlertControllerStyle.Alert by UIAlertControllerStyle.alert
                let DestructiveAction = UIAlertAction(title: "Delete", style: UIAlertAction.Style.destructive) {
                    (result : UIAlertAction) -> Void in
                    print("Delete")
                    self.deleteUser(userId: userId)
                }
                // Replace UIAlertActionStyle.Default by UIAlertActionStyle.default
                let okAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default) {
                    (result : UIAlertAction) -> Void in
                    print("Cancel")
                }
                alertController.addAction(DestructiveAction)
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
}

//MARK: - Other Methods
extension ViewController {
    
    func setView() {
        //setNavigation()
        self.navigationController?.navigationBar.isTranslucent = false
        self.IBuserTbl.tableFooterView = UIView()
    }
    //MARK: - Alert Function for testing only.
    func AlertMessage(msg:String){
        
        let alertController = UIAlertController(title: "Action", message: msg, preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { (result : UIAlertAction) -> Void in
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
}


//MARK: - Service Calll
extension ViewController {
    
    func getUserList() {
        
        let objUserModel:UserModel  = UserModel()
        
        let query                   = DBQuery().select(Obj: objUserModel)
        let JSONString              = DBHelper.getDataWithModel(strQuery: query, key: CustomModelName.Data)
        if let response = Mapper<ServiceResponseArray<UserModel>>().map(JSONString: JSONString) {
            if let user = response.Data {
                self.objUser = user
            }
        }
        self.IBuserTbl.reloadData()
    }
    
    func deleteUser(userId: CLong) {
        let objUserModel:UserModel       = UserModel()
        objUserModel.userId = userId
        if DBHelper.DeleteRecordFromTable(strQuery: DBQuery().delete(Obj: objUserModel)) {
            //self.userId = 0
            self.getUserList()
        }else {
            self.AlertMessage(msg: "Please try again..")
        }
    }
}


//MARK: Add User Delegate Method
extension ViewController : AddUserDelegate {
    func didFinishAddUser() {
        self.getUserList()
    }
}
