//
//  StudentCell.swift
//  DatabaseDemo
//
//  Created by Mehul Jadav.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class StudentCell: UITableViewCell {

    @IBOutlet weak var lblName                : UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    var user: UserModel? {
        didSet {
            if let username = user?.user_name {
                self.lblName.text = username
            }
        }
    }
}
